document.addEventListener('DOMContentLoaded', () => {
    const listEl = document.getElementById('list');
    const searchInput = document.getElementById('searchInput');
    const saveBtn = document.getElementById('saveBtn');
    const archiveBtn = document.getElementById('archiveBtn');
    const configBtn = document.getElementById('configBtn');
    const settingsSection = document.getElementById('settingsSection');
    const readFolderSelect = document.getElementById('readFolderSelect');
    const archiveFolderSelect = document.getElementById('archiveFolderSelect');
    const saveFolderBtn = document.getElementById('saveFolderBtn');
    const viewReadBtn = document.getElementById('viewReadBtn');
    const viewArchiveBtn = document.getElementById('viewArchiveBtn');

    let currentMode = 'read'; // 'read' or 'archive'
    let readFolderId = null;
    let archiveFolderId = null;

    // 加载存储的文件夹ID，并处理旧版兼容
    async function loadFolderIds() {
        const result = await chrome.storage.local.get(['readFolderId', 'archiveFolderId', 'folderId']);
        // 兼容旧版本：如果旧 folderId 存在且新设置不存在，则自动迁移
        if (result.folderId && !result.readFolderId && !result.archiveFolderId) {
            readFolderId = result.folderId;
            archiveFolderId = result.folderId;
            await chrome.storage.local.set({ readFolderId, archiveFolderId });
        } else {
            readFolderId = result.readFolderId || null;
            archiveFolderId = result.archiveFolderId || null;
        }
    }

    // 保存当前模式对应的文件夹ID
    async function saveFolderIds() {
        await chrome.storage.local.set({ readFolderId, archiveFolderId });
    }

    // 渲染列表：根据当前模式和搜索关键词
    async function renderList(query = '') {
        const folderId = currentMode === 'read' ? readFolderId : archiveFolderId;
        if (!folderId) {
            listEl.innerHTML = `<li style="border:none; color:#666;">请点击 ⚙️ 设置 ${currentMode === 'read' ? '稍后阅读' : '标签存档'} 文件夹</li>`;
            return;
        }

        try {
            // 检查文件夹是否存在
            await chrome.bookmarks.get(folderId);
        } catch (e) {
            listEl.innerHTML = '<li style="border:none; color:#666;">文件夹已被删除，请重新设置</li>';
            return;
        }

        try {
            const children = await chrome.bookmarks.getChildren(folderId);
            listEl.innerHTML = '';

            let filtered = children.filter(item => 
                item.title.toLowerCase().includes(query.toLowerCase())
            ).reverse();

            for (const item of filtered) {
                const li = document.createElement('li');
                const isFolder = !item.url;
                const isUnread = !isFolder && item.title.includes("🔵");
                let displayTitle = item.title.replace(/[🔵⚪]/g, "").trim();

                li.innerHTML = `
                    <button class="del-btn">✕</button>
                    <div class="status-icon" style="cursor:pointer;">
                        ${isFolder ? '📁' : (isUnread ? '🔵' : '⚪')}
                    </div>
                    <div class="item-info">
                        <a href="${isFolder ? '#' : item.url}" class="title ${!isUnread && !isFolder ? 'read-text' : ''}" target="_blank">
                            ${escapeHtml(displayTitle)}
                        </a>
                    </div>
                `;

                // 点击链接：未读变已读
                const titleLink = li.querySelector('.title');
                titleLink.onclick = async (e) => {
                    if (isFolder) {
                        e.preventDefault();
                        return;
                    }
                    if (isUnread) {
                        const newTitle = item.title.replace("🔵", "⚪");
                        await chrome.bookmarks.update(item.id, { title: newTitle });
                        renderList(searchInput.value);
                    }
                };

                // 点击图标切换读/未读
                const iconBtn = li.querySelector('.status-icon');
                if (!isFolder) {
                    iconBtn.onclick = async () => {
                        const newTitle = isUnread 
                            ? item.title.replace("🔵", "⚪")
                            : "🔵 " + item.title.replace(/[⚪]/g, "").trim();
                        await chrome.bookmarks.update(item.id, { title: newTitle });
                        renderList(searchInput.value);
                    };
                }

                // 删除逻辑
                li.querySelector('.del-btn').onclick = async () => {
                    if (isFolder) {
                        await chrome.bookmarks.removeTree(item.id);
                    } else {
                        await chrome.bookmarks.remove(item.id);
                    }
                    renderList(searchInput.value);
                };

                listEl.appendChild(li);
            }

            if (filtered.length === 0) {
                listEl.innerHTML = '<li style="border:none; color:#999;">暂无内容</li>';
            }
        } catch (e) {
            console.error(e);
            listEl.innerHTML = '<li style="border:none;">加载失败</li>';
        }
    }

    // 简单的防XSS
    function escapeHtml(str) {
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    // 保存当前页面到稍后阅读文件夹
    saveBtn.onclick = async () => {
        if (!readFolderId) {
            alert('请先在设置中指定“稍后阅读文件夹”');
            return;
        }
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.bookmarks.create({ 
            parentId: readFolderId, 
            title: "🔵 " + tab.title, 
            url: tab.url 
        });
        if (currentMode === 'read') renderList(searchInput.value);
        else alert('已保存到稍后阅读文件夹，当前视图为存档列表，可切换查看');
    };

    // 存档当前窗口所有标签到存档文件夹（创建时间子文件夹）
    archiveBtn.onclick = async () => {
        if (!archiveFolderId) {
            alert('请先在设置中指定“标签存档文件夹”');
            return;
        }
        const tabs = await chrome.tabs.query({ currentWindow: true });
        const timestamp = new Date().toLocaleString('zh-CN', { hour12: false });
        const newFolder = await chrome.bookmarks.create({ parentId: archiveFolderId, title: timestamp });
        for (const tab of tabs) {
            if (tab.url.startsWith('http')) {
                await chrome.bookmarks.create({ parentId: newFolder.id, title: "🔵 " + tab.title, url: tab.url });
            }
        }
        if (currentMode === 'archive') renderList(searchInput.value);
        else alert('已存档到指定文件夹，当前视图为待读列表，可切换查看');
    };

    // 设置界面：填充书签树
    async function populateFolderSelects() {
        const tree = await chrome.bookmarks.getTree();
        const walk = (nodes, depth = 0, selectEl) => {
            nodes.forEach(n => {
                if (!n.url) {
                    const opt = document.createElement('option');
                    opt.value = n.id;
                    opt.textContent = "\u00A0".repeat(depth * 2) + (n.title || "书签栏");
                    selectEl.appendChild(opt);
                    if (n.children) walk(n.children, depth + 1, selectEl);
                }
            });
        };

        readFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        archiveFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        walk(tree, 0, readFolderSelect);
        walk(tree, 0, archiveFolderSelect);

        if (readFolderId) readFolderSelect.value = readFolderId;
        if (archiveFolderId) archiveFolderSelect.value = archiveFolderId;
    }

    async function toggleSettings(force = false) {
        const show = force || window.getComputedStyle(settingsSection).display === 'none';
        settingsSection.style.display = show ? 'block' : 'none';
        if (show) {
            await populateFolderSelects();
        }
    }

    configBtn.onclick = () => toggleSettings();

    saveFolderBtn.onclick = async () => {
        const newReadId = readFolderSelect.value;
        const newArchiveId = archiveFolderSelect.value;
        if (!newReadId || !newArchiveId) {
            alert('请为两个文件夹都选择目录');
            return;
        }
        readFolderId = newReadId;
        archiveFolderId = newArchiveId;
        await saveFolderIds();
        settingsSection.style.display = 'none';
        renderList(searchInput.value);
    };

    // 视图切换
    function setMode(mode) {
        currentMode = mode;
        if (mode === 'read') {
            viewReadBtn.classList.add('active');
            viewArchiveBtn.classList.remove('active');
        } else {
            viewArchiveBtn.classList.add('active');
            viewReadBtn.classList.remove('active');
        }
        renderList(searchInput.value);
    }

    viewReadBtn.onclick = () => setMode('read');
    viewArchiveBtn.onclick = () => setMode('archive');

    searchInput.oninput = () => renderList(searchInput.value);

    // 初始化
    async function init() {
        await loadFolderIds();
        if (!readFolderId || !archiveFolderId) {
            // 如果缺少任一文件夹，自动打开设置面板
            toggleSettings(true);
            listEl.innerHTML = '<li style="border:none; color:#666;">请完成文件夹设置后使用</li>';
        } else {
            setMode('read'); // 默认显示待读列表
        }
    }
    init();
});