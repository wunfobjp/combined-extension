document.addEventListener('DOMContentLoaded', () => {
    const listEl = document.getElementById('list');
    const searchInput = document.getElementById('searchInput');
    const saveBtn = document.getElementById('saveBtn');
    const archiveBtn = document.getElementById('archiveBtn');
    const configBtn = document.getElementById('configBtn');
    const settingsSection = document.getElementById('settingsSection');
    const folderSelect = document.getElementById('folderSelect');
    const saveFolderBtn = document.getElementById('saveFolderBtn');

    async function init() {
        const { folderId } = await chrome.storage.local.get('folderId');
        if (!folderId) {
            listEl.innerHTML = '<li style="border:none; color:#666;">请点击 ⚙️ 设置文件夹</li>';
            toggleSettings(true);
        } else { renderList(); }
    }

    async function renderList(query = '') {
        const { folderId } = await chrome.storage.local.get('folderId');
        if (!folderId) return;

        try {
            const children = await chrome.bookmarks.getChildren(folderId);
            listEl.innerHTML = '';

            const filtered = children.filter(item => 
                item.title.toLowerCase().includes(query.toLowerCase())
            ).reverse();

            filtered.forEach(item => {
                const li = document.createElement('li');
                const isFolder = !item.url;
                
                // 判断逻辑
                const isUnread = item.title.includes("🔵");
                let displayTitle = item.title.replace("🔵", "").replace("⚪", "").trim();

                li.innerHTML = `
                    <button class="del-btn">✕</button>
                    <div class="status-icon" style="cursor:pointer;">
                        ${isFolder ? '📁' : (isUnread ? '🔵' : '⚪')}
                    </div>
                    <div class="item-info">
                        <a href="${isFolder ? '#' : item.url}" class="title ${!isUnread && !isFolder ? 'read-text' : ''}" target="_blank">
                            ${displayTitle}
                        </a>
                    </div>
                `;

                // 绑定点击跳转变已读
                const titleLink = li.querySelector('.title');
                titleLink.onclick = async (e) => {
                    if (isFolder) { e.preventDefault(); return; }
                    if (isUnread) {
                        const newTitle = item.title.replace("🔵", "⚪");
                        await chrome.bookmarks.update(item.id, { title: newTitle });
                    }
                };

                // 绑定图标点击切换
                const iconBtn = li.querySelector('.status-icon');
                if (!isFolder) {
                    iconBtn.onclick = async () => {
                        const newTitle = isUnread ? item.title.replace("🔵", "⚪") : "🔵 " + item.title.replace("⚪", "").trim();
                        await chrome.bookmarks.update(item.id, { title: newTitle });
                        renderList(searchInput.value);
                    };
                }

                // 删除逻辑
                li.querySelector('.del-btn').onclick = async () => {
                    isFolder ? await chrome.bookmarks.removeTree(item.id) : await chrome.bookmarks.remove(item.id);
                    renderList(searchInput.value);
                };

                listEl.appendChild(li);
            });
        } catch (e) { listEl.innerHTML = '<li style="border:none;">文件夹已失效</li>'; }
    }

    // 保存逻辑
    saveBtn.onclick = async () => {
        const { folderId } = await chrome.storage.local.get('folderId');
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.bookmarks.create({ parentId: folderId, title: "🔵 " + tab.title, url: tab.url });
        renderList();
    };

    archiveBtn.onclick = async () => {
        const { folderId } = await chrome.storage.local.get('folderId');
        const tabs = await chrome.tabs.query({ currentWindow: true });
        const timestamp = new Date().toLocaleString('zh-CN', { hour12: false });
        const newFolder = await chrome.bookmarks.create({ parentId: folderId, title: timestamp });
        for (const tab of tabs) {
            if (tab.url.startsWith('http')) {
                await chrome.bookmarks.create({ parentId: newFolder.id, title: "🔵 " + tab.title, url: tab.url });
            }
        }
        renderList();
    };

    // 设置逻辑
    async function toggleSettings(force = false) {
        const show = force || window.getComputedStyle(settingsSection).display === 'none';
        settingsSection.style.display = show ? 'block' : 'none';
        if (show) {
            const tree = await chrome.bookmarks.getTree();
            folderSelect.innerHTML = '';
            const walk = (nodes, depth = 0) => {
                nodes.forEach(n => {
                    if (!n.url) {
                        const opt = document.createElement('option');
                        opt.value = n.id;
                        opt.textContent = "\u00A0".repeat(depth*2) + (n.title || "书签栏");
                        folderSelect.appendChild(opt);
                        if (n.children) walk(n.children, depth + 1);
                    }
                });
            };
            walk(tree);
            const data = await chrome.storage.local.get('folderId');
            if (data.folderId) folderSelect.value = data.folderId;
        }
    }
    configBtn.onclick = () => toggleSettings();
    saveFolderBtn.onclick = async () => {
        await chrome.storage.local.set({ folderId: folderSelect.value });
        settingsSection.style.display = 'none';
        renderList();
    };
    searchInput.oninput = () => renderList(searchInput.value);
    init();
});
