document.addEventListener('DOMContentLoaded', () => {
    const listEl = document.getElementById('list');
    const searchInput = document.getElementById('searchInput');
    const saveBtn = document.getElementById('saveBtn');
    const archiveBtn = document.getElementById('archiveBtn');
    const configBtn = document.getElementById('configBtn');
    const settingsSection = document.getElementById('settingsSection');
    const folderSelect = document.getElementById('folderSelect');
    const saveFolderBtn = document.getElementById('saveFolderBtn');

    // 1. 初始化启动
    async function init() {
        const { folderId } = await chrome.storage.local.get('folderId');
        if (!folderId) {
            listEl.innerHTML = '<li class="hint">请点击上方 ⚙️ 图标配置文件夹</li>';
            toggleSettings(true);
        } else {
            renderList();
        }
    }

    // 2. 核心渲染函数
    async function renderList(query = '') {
        const { folderId } = await chrome.storage.local.get('folderId');
        if (!folderId) return;

        try {
            const children = await chrome.bookmarks.getChildren(folderId);
            listEl.innerHTML = '';

            // 过滤匹配项并倒序（最新的在前）
            const filtered = children.filter(item => 
                item.title.toLowerCase().includes(query.toLowerCase())
            ).reverse();

            if (filtered.length === 0) {
                listEl.innerHTML = '<li class="hint">暂无匹配内容</li>';
                return;
            }

            filtered.forEach(item => {
                const li = document.createElement('li');
                const isFolder = !item.url;

                // 结构：删除按钮在前，标题在后
                li.innerHTML = `
                    <button class="del-btn" title="删除">✕</button>
                    <div class="item-info">
                        <a href="${isFolder ? '#' : item.url}" class="title" target="_blank">
                            ${isFolder ? '📁 ' + item.title : item.title}
                        </a>
                    </div>
                `;

                // 文件夹点击阻止默认行为
                if (isFolder) {
                    li.querySelector('.title').onclick = (e) => e.preventDefault();
                }

                // 删除逻辑
                li.querySelector('.del-btn').onclick = async (e) => {
                    e.stopPropagation();
                    if (isFolder) {
                        await chrome.bookmarks.removeTree(item.id);
                    } else {
                        await chrome.bookmarks.remove(item.id);
                    }
                    renderList(searchInput.value);
                };

                listEl.appendChild(li);
            });
        } catch (e) {
            listEl.innerHTML = '<li class="hint">文件夹已失效，请重新设置</li>';
        }
    }

    // 3. 功能：保存单页
    saveBtn.onclick = async () => {
        const { folderId } = await chrome.storage.local.get('folderId');
        if (!folderId) return toggleSettings(true);

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.bookmarks.create({
            parentId: folderId,
            title: tab.title,
            url: tab.url
        });
        renderList();
    };

    // 4. 功能：批量存档 (Tab Saver)
    archiveBtn.onclick = async () => {
        const { folderId } = await chrome.storage.local.get('folderId');
        if (!folderId) return toggleSettings(true);

        const tabs = await chrome.tabs.query({ currentWindow: true });
        const timestamp = new Date().toLocaleString('zh-CN', { hour12: false });

        // 创建存档子文件夹
        const newFolder = await chrome.bookmarks.create({
            parentId: folderId,
            title: timestamp
        });

        for (const tab of tabs) {
            if (tab.url.startsWith('http')) {
                await chrome.bookmarks.create({
                    parentId: newFolder.id,
                    title: tab.title,
                    url: tab.url
                });
            }
        }
        renderList();
    };

    // 5. 功能：设置面板切换
    async function toggleSettings(forceShow = false) {
        const isHidden = window.getComputedStyle(settingsSection).display === 'none';
        const show = forceShow === true ? true : isHidden;
        settingsSection.style.display = show ? 'block' : 'none';
        
        if (show) {
            const tree = await chrome.bookmarks.getTree();
            folderSelect.innerHTML = '';
            const walk = (nodes, depth = 0) => {
                nodes.forEach(node => {
                    if (!node.url) {
                        const opt = document.createElement('option');
                        opt.value = node.id;
                        opt.textContent = "\u00A0".repeat(depth * 2) + (node.title || "根目录");
                        folderSelect.appendChild(opt);
                        if (node.children) walk(node.children, depth + 1);
                    }
                });
            };
            walk(tree);
            const data = await chrome.storage.local.get('folderId');
            if (data.folderId) folderSelect.value = data.folderId;
        }
    }

    // 6. 事件绑定
    configBtn.onclick = () => toggleSettings();
    saveFolderBtn.onclick = async () => {
        await chrome.storage.local.set({ folderId: folderSelect.value });
        settingsSection.style.display = 'none';
        renderList();
    };
    searchInput.oninput = () => renderList(searchInput.value);

    init();
});
