document.addEventListener('DOMContentLoaded', () => {
    const listEl = document.getElementById('list');
    const searchInput = document.getElementById('searchInput');
    const saveBtn = document.getElementById('saveBtn');
    const archiveBtn = document.getElementById('archiveBtn');
    const configBtn = document.getElementById('configBtn');
    const settingsSection = document.getElementById('settingsSection');
    const readFolderSelect = document.getElementById('readFolderSelect');
    const archiveFolderSelect = document.getElementById('archiveFolderSelect');
    const saveFolderBtn = document.getElementById('saveFolderBtn');
    const viewReadBtn = document.getElementById('viewReadBtn');
    const viewArchiveBtn = document.getElementById('viewArchiveBtn');
    const navBar = document.getElementById('navBar');
    const backBtn = document.getElementById('backBtn');
    const currentPathSpan = document.getElementById('currentPath');

    let currentMode = 'read';         // 'read' or 'archive'
    let readFolderId = null;
    let archiveFolderId = null;

    // 浏览状态
    let currentFolderId = null;        // 当前正在浏览的文件夹ID
    let folderStack = [];              // 存储父文件夹 { id, title }

    // 加载存储的文件夹ID，兼容旧版
    async function loadFolderIds() {
        const result = await chrome.storage.local.get(['readFolderId', 'archiveFolderId', 'folderId']);
        if (result.folderId && !result.readFolderId && !result.archiveFolderId) {
            readFolderId = result.folderId;
            archiveFolderId = result.folderId;
            await chrome.storage.local.set({ readFolderId, archiveFolderId });
        } else {
            readFolderId = result.readFolderId || null;
            archiveFolderId = result.archiveFolderId || null;
        }
    }

    async function saveFolderIds() {
        await chrome.storage.local.set({ readFolderId, archiveFolderId });
    }

    // 获取当前模式对应的根文件夹ID
    function getRootFolderId() {
        return currentMode === 'read' ? readFolderId : archiveFolderId;
    }

    // 重置导航到根目录
    async function resetNavigation() {
        const rootId = getRootFolderId();
        if (!rootId) return;
        currentFolderId = rootId;
        folderStack = [];
        await updateNavBar(rootId);
        renderList(searchInput.value);
    }

    // 更新导航栏显示
    async function updateNavBar(folderId) {
        if (!folderId) {
            navBar.style.display = 'none';
            return;
        }
        const rootId = getRootFolderId();
        if (folderId === rootId && folderStack.length === 0) {
            navBar.style.display = 'none';
            return;
        }
        navBar.style.display = 'flex';
        // 显示当前文件夹标题
        try {
            const node = await chrome.bookmarks.get(folderId);
            if (node && node[0]) {
                currentPathSpan.textContent = node[0].title || '未命名';
            } else {
                currentPathSpan.textContent = '文件夹';
            }
        } catch (e) {
            currentPathSpan.textContent = '文件夹';
        }
    }

    // 进入文件夹
    async function openFolder(folderId, folderTitle) {
        if (!folderId) return;
        // 保存当前路径到栈
        if (currentFolderId) {
            let currentTitle = '根目录';
            try {
                const node = await chrome.bookmarks.get(currentFolderId);
                if (node && node[0]) currentTitle = node[0].title;
            } catch (e) {}
            folderStack.push({ id: currentFolderId, title: currentTitle });
        }
        currentFolderId = folderId;
        await updateNavBar(folderId);
        renderList(searchInput.value);
    }

    // 返回上一级
    async function goBack() {
        if (folderStack.length === 0) {
            // 回到根目录
            const rootId = getRootFolderId();
            if (rootId) {
                currentFolderId = rootId;
                folderStack = [];
                await updateNavBar(rootId);
                renderList(searchInput.value);
            }
        } else {
            const parent = folderStack.pop();
            currentFolderId = parent.id;
            await updateNavBar(parent.id);
            renderList(searchInput.value);
        }
    }

    backBtn.onclick = goBack;

    // 渲染列表（支持当前文件夹）
    async function renderList(query = '') {
        if (!currentFolderId) {
            const rootId = getRootFolderId();
            if (!rootId) {
                listEl.innerHTML = `<li style="border:none; color:#666;">请点击 ⚙️ 设置 ${currentMode === 'read' ? '稍后阅读' : '标签存档'} 文件夹</li>`;
                navBar.style.display = 'none';
                return;
            } else {
                currentFolderId = rootId;
                folderStack = [];
                await updateNavBar(rootId);
            }
        }

        try {
            await chrome.bookmarks.get(currentFolderId);
        } catch (e) {
            listEl.innerHTML = '<li style="border:none; color:#666;">文件夹已被删除，请重新设置</li>';
            navBar.style.display = 'none';
            return;
        }

        try {
            const children = await chrome.bookmarks.getChildren(currentFolderId);
            listEl.innerHTML = '';

            let filtered = children.filter(item =>
                item.title.toLowerCase().includes(query.toLowerCase())
            ).reverse();

            for (const item of filtered) {
                const li = document.createElement('li');
                const isFolder = !item.url;
                const isUnread = !isFolder && item.title.includes("🔵");
                let displayTitle = item.title.replace(/[🔵⚪]/g, "").trim();

                li.innerHTML = `
                    <button class="del-btn">✕</button>
                    <div class="status-icon" style="cursor:pointer;">
                        ${isFolder ? '📁' : (isUnread ? '🔵' : '⚪')}
                    </div>
                    <div class="item-info">
                        <a href="${isFolder ? '#' : item.url}" class="title ${!isUnread && !isFolder ? 'read-text' : ''}" target="_blank">
                            ${escapeHtml(displayTitle)}
                        </a>
                    </div>
                `;

                const titleLink = li.querySelector('.title');
                const iconBtn = li.querySelector('.status-icon');

                if (isFolder) {
                    // 文件夹：点击链接或图标都进入文件夹
                    const enterHandler = (e) => {
                        e.preventDefault();
                        openFolder(item.id, item.title);
                    };
                    titleLink.onclick = enterHandler;
                    iconBtn.onclick = enterHandler;
                } else {
                    // 书签：点击链接跳转并标记已读
                    titleLink.onclick = async (e) => {
                        if (isUnread) {
                            const newTitle = item.title.replace("🔵", "⚪");
                            await chrome.bookmarks.update(item.id, { title: newTitle });
                        }
                        // 允许正常跳转
                    };
                    // 点击图标切换读/未读
                    iconBtn.onclick = async () => {
                        const newTitle = isUnread
                            ? item.title.replace("🔵", "⚪")
                            : "🔵 " + item.title.replace(/[⚪]/g, "").trim();
                        await chrome.bookmarks.update(item.id, { title: newTitle });
                        renderList(searchInput.value);
                    };
                }

                // 删除逻辑
                li.querySelector('.del-btn').onclick = async () => {
                    if (isFolder) {
                        await chrome.bookmarks.removeTree(item.id);
                        // 如果删除的是当前文件夹或祖先，重置导航
                        if (item.id === currentFolderId || folderStack.some(f => f.id === item.id)) {
                            await resetNavigation();
                        } else {
                            renderList(searchInput.value);
                        }
                    } else {
                        await chrome.bookmarks.remove(item.id);
                        renderList(searchInput.value);
                    }
                };

                listEl.appendChild(li);
            }

            if (filtered.length === 0) {
                listEl.innerHTML = '<li style="border:none; color:#999;">暂无内容</li>';
            }
        } catch (e) {
            console.error(e);
            listEl.innerHTML = '<li style="border:none;">加载失败</li>';
        }
    }

    function escapeHtml(str) {
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    // 保存单页到稍后阅读根目录
    saveBtn.onclick = async () => {
        if (!readFolderId) {
            alert('请先在设置中指定“稍后阅读文件夹”');
            return;
        }
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.bookmarks.create({
            parentId: readFolderId,
            title: "🔵 " + tab.title,
            url: tab.url
        });
        if (currentMode === 'read') {
            await resetNavigation(); // 回到根目录并刷新
        } else {
            alert('已保存到稍后阅读文件夹，当前视图为存档列表，可切换查看');
        }
    };

    // 存档当前窗口到存档根目录（创建时间子文件夹）
    archiveBtn.onclick = async () => {
        if (!archiveFolderId) {
            alert('请先在设置中指定“标签存档文件夹”');
            return;
        }
        const tabs = await chrome.tabs.query({ currentWindow: true });
        const timestamp = new Date().toLocaleString('zh-CN', { hour12: false });
        const newFolder = await chrome.bookmarks.create({ parentId: archiveFolderId, title: timestamp });
        for (const tab of tabs) {
            if (tab.url.startsWith('http')) {
                await chrome.bookmarks.create({ parentId: newFolder.id, title: "🔵 " + tab.title, url: tab.url });
            }
        }
        if (currentMode === 'archive') {
            await resetNavigation();
        } else {
            alert('已存档到指定文件夹，当前视图为待读列表，可切换查看');
        }
    };

    // 设置界面
    async function populateFolderSelects() {
        const tree = await chrome.bookmarks.getTree();
        const walk = (nodes, depth = 0, selectEl) => {
            nodes.forEach(n => {
                if (!n.url) {
                    const opt = document.createElement('option');
                    opt.value = n.id;
                    opt.textContent = "\u00A0".repeat(depth * 2) + (n.title || "书签栏");
                    selectEl.appendChild(opt);
                    if (n.children) walk(n.children, depth + 1, selectEl);
                }
            });
        };
        readFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        archiveFolderSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        walk(tree, 0, readFolderSelect);
        walk(tree, 0, archiveFolderSelect);
        if (readFolderId) readFolderSelect.value = readFolderId;
        if (archiveFolderId) archiveFolderSelect.value = archiveFolderId;
    }

    async function toggleSettings(force = false) {
        const show = force || window.getComputedStyle(settingsSection).display === 'none';
        settingsSection.style.display = show ? 'block' : 'none';
        if (show) await populateFolderSelects();
    }
    configBtn.onclick = () => toggleSettings();

    saveFolderBtn.onclick = async () => {
        const newReadId = readFolderSelect.value;
        const newArchiveId = archiveFolderSelect.value;
        if (!newReadId || !newArchiveId) {
            alert('请为两个文件夹都选择目录');
            return;
        }
        readFolderId = newReadId;
        archiveFolderId = newArchiveId;
        await saveFolderIds();
        settingsSection.style.display = 'none';
        // 重置当前模式的导航
        if (currentMode === 'read') {
            currentFolderId = readFolderId;
        } else {
            currentFolderId = archiveFolderId;
        }
        folderStack = [];
        await updateNavBar(currentFolderId);
        renderList(searchInput.value);
    };

    // 切换待读/存档模式
    function setMode(mode) {
        currentMode = mode;
        if (mode === 'read') {
            viewReadBtn.classList.add('active');
            viewArchiveBtn.classList.remove('active');
        } else {
            viewArchiveBtn.classList.add('active');
            viewReadBtn.classList.remove('active');
        }
        // 重置浏览状态
        const rootId = getRootFolderId();
        if (rootId) {
            currentFolderId = rootId;
            folderStack = [];
            updateNavBar(rootId);
            renderList(searchInput.value);
        } else {
            currentFolderId = null;
            folderStack = [];
            navBar.style.display = 'none';
            renderList('');
        }
    }

    viewReadBtn.onclick = () => setMode('read');
    viewArchiveBtn.onclick = () => setMode('archive');

    searchInput.oninput = () => renderList(searchInput.value);

    async function init() {
        await loadFolderIds();
        if (!readFolderId || !archiveFolderId) {
            toggleSettings(true);
            listEl.innerHTML = '<li style="border:none; color:#666;">请完成文件夹设置后使用</li>';
        } else {
            setMode('read');
        }
    }
    init();
});